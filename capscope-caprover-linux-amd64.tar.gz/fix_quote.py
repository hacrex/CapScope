path = "internal/api/server.go"

with open(path, 'r') as f:
    content = f.read()

# Fix backslash rune: currently '\': which Go can't parse
# Need: '\\'': 0x10084,
content = content.replace("\t'\\': 0x10084,", "\t'\\\\': 0x10084,")

with open(path, 'w') as f:
    f.write(content)

print("Fixed backslash rune literal")
