package api

import (
	"bufio"
	"context"
	"encoding/json"
	"io"
	"log/slog"
	"net/http"
	"net/http/httptest"
	"net/url"
	"path/filepath"
	"strconv"
	"strings"
	"testing"
	"time"

	"capscope/internal/auth"
	"capscope/internal/collector"
	"capscope/internal/config"
	"capscope/internal/docker"
	"capscope/internal/hub"
	"capscope/internal/store"

	"golang.org/x/crypto/bcrypt"
)

var (
	testServerURL string
	testToken     string
)

func setup(t *testing.T) (*httptest.Server, *store.Store, *hub.Hub) {
	t.Helper()
	st, err := store.Open(filepath.Join(t.TempDir(), "a.db"))
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { st.Close() })
	h := hub.New()
	cfg := config.Config{AuthUser: "u", AuthPass: "p", SnapshotKinds: map[string]bool{}}
	dk, _ := docker.New("tcp://127.0.0.1:1")
	mgr := collector.NewManager(cfg, dk, st, h, slog.New(slog.NewTextHandler(io.Discard, nil)))
	as := auth.NewSessionManager(slog.Default())
	// Seed the first user from AUTH_USER/AUTH_PASS
	hash, _ := bcrypt.GenerateFromPassword([]byte("p"), bcrypt.DefaultCost)
	_, _ = st.SeedFirstUser("u", string(hash))
	srv := httptest.NewServer(New(cfg, st, mgr, h, slog.Default(), WithAuth(as)).Handler())
	t.Cleanup(srv.Close)
	testServerURL = srv.URL
	testToken = "" // force re-login against the new server
	return srv, st, h
}

// loginToken returns a bearer token obtained from /api/login on the given
// server. Each call creates an independent session so tests that run their own
// httptest servers never depend on package-level state left behind by others.
func loginToken(t *testing.T, baseURL string) string {
	t.Helper()
	req, _ := http.NewRequest("POST", baseURL+"/api/login", strings.NewReader(`{"username":"u","password":"p"}`))
	req.Header.Set("Content-Type", "application/json")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		t.Fatalf("login failed: %d", resp.StatusCode)
	}
	var out struct {
		Token string `json:"token"`
	}
	_ = json.NewDecoder(resp.Body).Decode(&out)
	if out.Token == "" {
		t.Fatal("login response missing token")
	}
	return out.Token
}

// loginIfNeeded keeps the legacy call sites working: it refreshes the cached
// token against testServerURL. Prefer loginToken(srv.URL) in new tests.
func loginIfNeeded(t *testing.T, baseURL ...string) {
	t.Helper()
	url := testServerURL
	if len(baseURL) > 0 && baseURL[0] != "" {
		url = baseURL[0]
	}
	testServerURL = url
	testToken = loginToken(t, url)
}

// serverForURL derives the httptest server base (scheme://host) from a request
// URL so get() can authenticate against whichever server the caller targets.
func serverForURL(u string) string {
	parsed, err := url.Parse(u)
	if err != nil || parsed.Host == "" {
		return testServerURL
	}
	return parsed.Scheme + "://" + parsed.Host
}

func get(t *testing.T, url string, auth bool) *http.Response {
	t.Helper()
	req, _ := http.NewRequest("GET", url, nil)
	if auth {
		loginIfNeeded(t, serverForURL(url))
		req.Header.Set("Authorization", "Bearer "+testToken)
	}
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	return resp
}

func TestAuthAndUI(t *testing.T) {
	srv, _, _ := setup(t)
	if r := get(t, srv.URL+"/api/logs", false); r.StatusCode != 401 {
		t.Errorf("want 401 without credentials, got %d", r.StatusCode)
	}
	if r := get(t, srv.URL+"/healthz", false); r.StatusCode != 200 {
		t.Errorf("healthz should be open, got %d", r.StatusCode)
	}

	// Login flow: valid credentials issue a token.
	req, _ := http.NewRequest("POST", srv.URL+"/api/login", strings.NewReader(`{"username":"u","password":"p"}`))
	req.Header.Set("Content-Type", "application/json")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		t.Errorf("login should succeed, got %d", resp.StatusCode)
	}
	var out struct {
		Token string `json:"token"`
		User  string `json:"user"`
	}
	_ = json.NewDecoder(resp.Body).Decode(&out)
	if out.Token == "" || out.User != "u" {
		t.Errorf("login should return token and user, got %+v", out)
	}

	// The token works for authenticated requests.
	r := get(t, srv.URL+"/", true)
	if r.StatusCode != 200 {
		t.Errorf("UI should be served with token, got %d", r.StatusCode)
	}

	// Wrong password is rejected.
	req2, _ := http.NewRequest("POST", srv.URL+"/api/login", strings.NewReader(`{"username":"u","password":"wrong"}`))
	req2.Header.Set("Content-Type", "application/json")
	resp2, err := http.DefaultClient.Do(req2)
	if err != nil {
		t.Fatal(err)
	}
	defer resp2.Body.Close()
	if resp2.StatusCode != 401 {
		t.Errorf("wrong password should be 401, got %d", resp2.StatusCode)
	}

	// /api/session reflects the logged-in user.
	req3, _ := http.NewRequest("GET", srv.URL+"/api/session", nil)
	req3.Header.Set("Authorization", "Bearer "+out.Token)
	resp3, err := http.DefaultClient.Do(req3)
	if err != nil {
		t.Fatal(err)
	}
	defer resp3.Body.Close()
	if resp3.StatusCode != 200 {
		t.Errorf("session should be 200 with token, got %d", resp3.StatusCode)
	}

	// Logout invalidates the token.
	req4, _ := http.NewRequest("POST", srv.URL+"/api/logout", nil)
	req4.Header.Set("Authorization", "Bearer "+out.Token)
	resp4, err := http.DefaultClient.Do(req4)
	if err != nil {
		t.Fatal(err)
	}
	defer resp4.Body.Close()
	if resp4.StatusCode != 200 {
		t.Errorf("logout should succeed, got %d", resp4.StatusCode)
	}
	// After logout the token no longer works.
	req5, _ := http.NewRequest("GET", srv.URL+"/api/session", nil)
	req5.Header.Set("Authorization", "Bearer "+out.Token)
	resp5, err := http.DefaultClient.Do(req5)
	if err != nil {
		t.Fatal(err)
	}
	defer resp5.Body.Close()
	if resp5.StatusCode != 401 {
		t.Errorf("session should be 401 after logout, got %d", resp5.StatusCode)
	}
}

func TestLogsAPIAndSnapshotExport(t *testing.T) {
	srv, st, _ := setup(t)
	now := time.Now()
	_ = st.InsertLogs([]store.LogRow{
		{TS: now.UnixNano(), TSMs: now.UnixMilli(), ContainerID: "c1", Container: "web.1", App: "web", Stream: "o", Level: "info", Line: "hello"},
		{TS: now.UnixNano(), TSMs: now.UnixMilli(), ContainerID: "c1", Container: "web.1", App: "web", Stream: "e", Level: "error", Line: "bad thing"},
	})
	var out struct{ Logs []store.LogRow }
	resp := get(t, srv.URL+"/api/logs?app=web&level=error", true)
	_ = json.NewDecoder(resp.Body).Decode(&out)
	if len(out.Logs) != 1 || out.Logs[0].Line != "bad thing" {
		t.Fatalf("logs: %+v", out.Logs)
	}
	if r := get(t, srv.URL+"/api/logs?q=(&regex=1", true); r.StatusCode != 400 {
		t.Errorf("bad regex should be 400, got %d", r.StatusCode)
	}
	id, _ := st.InsertSnapshot(store.Snapshot{TS: now.UnixMilli(), Kind: "crash", App: "web", Container: "web.1", ExitCode: 1, Summary: "s",
		Logs: []store.LogRow{{TSMs: now.UnixMilli(), Line: "last line", Stream: "e"}}})
	r := get(t, srv.URL+"/api/snapshots/"+itoa(id)+"/export", true)
	b, _ := io.ReadAll(r.Body)
	if !strings.Contains(string(b), "# Crash report: web") || !strings.Contains(string(b), "last line") {
		t.Errorf("markdown export: %s", b)
	}
}

func itoa(n int64) string { return strconv.FormatInt(n, 10) }

func TestSQLAPI(t *testing.T) {
	srv, st, _ := setup(t)
	now := time.Now()
	_ = st.InsertLogs([]store.LogRow{
		{TS: now.UnixNano(), TSMs: now.UnixMilli(), ContainerID: "c1", Container: "web.1", App: "web", Stream: "o", Level: "info", Line: "hello"},
		{TS: now.UnixNano(), TSMs: now.UnixMilli(), ContainerID: "c1", Container: "web.1", App: "web", Stream: "e", Level: "error", Line: "bad thing"},
	})
	q := url.QueryEscape("SELECT level, count(*) AS n FROM logs GROUP BY level ORDER BY level")
	var out struct {
		Columns   []string `json:"columns"`
		Rows      [][]any  `json:"rows"`
		Truncated bool     `json:"truncated"`
		MS        int64    `json:"ms"`
	}
	resp := get(t, srv.URL+"/api/sql?query="+q, true)
	_ = json.NewDecoder(resp.Body).Decode(&out)
	if resp.StatusCode != 200 || len(out.Columns) != 2 || out.Columns[0] != "level" || len(out.Rows) != 2 {
		t.Fatalf("sql: %d %+v", resp.StatusCode, out)
	}
	if r := get(t, srv.URL+"/api/sql?query="+url.QueryEscape("DELETE FROM logs"), true); r.StatusCode != 400 {
		t.Errorf("write statement should be 400, got %d", r.StatusCode)
	}
	if r := get(t, srv.URL+"/api/sql?query=SELECT%201", false); r.StatusCode != 401 {
		t.Errorf("sql should require auth, got %d", r.StatusCode)
	}
	// The rejected write must not have run.
	var still struct{ Rows [][]any }
	resp = get(t, srv.URL+"/api/sql?query="+url.QueryEscape("SELECT count(*) FROM logs"), true)
	_ = json.NewDecoder(resp.Body).Decode(&still)
	if len(still.Rows) != 1 || still.Rows[0][0].(float64) != 2 {
		t.Fatalf("rows after rejected write: %+v", still.Rows)
	}
}

func TestAccessAPIAndExports(t *testing.T) {
	srv, st, _ := setup(t)
	now := time.Now()
	rows := []store.AccessRow{
		{TS: now.UnixMilli() - 2000, Container: "captain-nginx", App: "nginx", IP: "203.0.113.0", Method: "GET", Path: "/api/items", Status: 200, Bytes: 120, Referer: "https://r.io", UA: "curl"},
		{TS: now.UnixMilli() - 1000, Container: "captain-nginx", App: "nginx", IP: "203.0.113.0", Method: "GET", Path: "/api/items", Status: 502, Bytes: 40},
	}
	if err := st.InsertAccess(rows); err != nil {
		t.Fatal(err)
	}
	var agg struct {
		Totals struct {
			Requests int64
			Bytes    int64
		}
		Paths []store.AccessTop
	}
	resp := get(t, srv.URL+"/api/access?range=1h", true)
	if err := json.NewDecoder(resp.Body).Decode(&agg); err != nil {
		t.Fatal(err)
	}
	if agg.Totals.Requests != 2 || agg.Totals.Bytes != 160 {
		t.Errorf("totals: %+v", agg.Totals)
	}
	if len(agg.Paths) != 1 || agg.Paths[0].Key != "/api/items" || agg.Paths[0].Errors != 1 {
		t.Errorf("paths: %+v", agg.Paths)
	}
	// CSV export contains the parsed rows
	r := get(t, srv.URL+"/api/access/export?range=1h", true)
	b, _ := io.ReadAll(r.Body)
	s := string(b)
	if !strings.Contains(r.Header.Get("Content-Disposition"), "capscope-access.csv") || !strings.Contains(s, "/api/items,200") || !strings.Contains(s, "user_agent") {
		t.Errorf("access csv: %q", s)
	}
	// log export: CSV of the logs table, with CSV quoting
	var many []store.LogRow
	for i := 0; i < 600; i++ {
		many = append(many, store.LogRow{TS: now.UnixNano(), TSMs: now.UnixMilli(), ContainerID: "c1", Container: "web.1", App: "web", Stream: "e", Level: "error", Line: `something "bad", happened`})
	}
	_ = st.InsertLogs(append(many, store.LogRow{TS: now.UnixNano(), TSMs: now.UnixMilli(), ContainerID: "c1", Container: "web.1", App: "web", Stream: "e", Level: "error", Line: `last row`}))
	r = get(t, srv.URL+"/api/logs/export?app=web", true)
	b, _ = io.ReadAll(r.Body)
	s = string(b)
	// CSV doubles embedded quotes, so the cell reads: something ""bad"", happened
	if !strings.Contains(s, "stderr") || !strings.Contains(s, `something ""bad"", happened`) {
		t.Errorf("logs csv: %q", s)
	}
	// paging must reach past the 500-row query default (regression: old code
	// compared page size against a hardcoded 5000 and stopped after one page)
	if n := strings.Count(s, "\n"); n < 601 {
		t.Errorf("logs export truncated at first page: %d lines", n-1)
	}
	if !strings.Contains(s, "last row") {
		t.Errorf("logs export missing final row")
	}

	// Raw text export: the raw lines only, no CSV quoting, same paging ceiling.
	r = get(t, srv.URL+"/api/logs/raw?app=web", true)
	b, _ = io.ReadAll(r.Body)
	s = string(b)
	if got := r.Header.Get("Content-Type"); got != "text/plain; charset=utf-8" {
		t.Errorf("raw export content type: %q", got)
	}
	if !strings.Contains(r.Header.Get("Content-Disposition"), "capscope-logs.txt") {
		t.Errorf("raw export disposition: %q", r.Header.Get("Content-Disposition"))
	}
	// Bytes are emitted verbatim; the CSV-quoted variant must not appear.
	if !strings.Contains(s, `something "bad", happened`) || strings.Contains(s, `""bad""`) {
		head := s
		if len(head) > 200 {
			head = head[:200]
		}
		t.Errorf("raw export quoting wrong: %q", head)
	}
	// Same paging correctness as the CSV path (601 rows).
	if n := strings.Count(s, "\n"); n != 600 {
		t.Errorf("raw export rows = %d separators, want exactly 600 (last, newline-terminated file)", n)
	}
	if !strings.Contains(s, "last row") {
		t.Errorf("raw export missing final row")
	}
}

func TestAccessExportsRequireAuth(t *testing.T) {
	srv, _, _ := setup(t)
	if r := get(t, srv.URL+"/api/access", false); r.StatusCode != 401 {
		t.Errorf("access should require auth, got %d", r.StatusCode)
	}
	if r := get(t, srv.URL+"/api/logs/export", false); r.StatusCode != 401 {
		t.Errorf("logs export should require auth, got %d", r.StatusCode)
	}
}

func TestSSEDeliversPublishedRows(t *testing.T) {
	srv, _, h := setup(t)
	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	req, _ := http.NewRequestWithContext(ctx, "GET", srv.URL+"/api/logs/stream?app=web", nil)
	loginIfNeeded(t)
	req.Header.Set("Authorization", "Bearer "+testToken)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	sc := bufio.NewScanner(resp.Body)
	sc.Scan() // ": connected"
	go func() {
		time.Sleep(100 * time.Millisecond)
		h.Publish([]store.LogRow{
			{ID: 1, App: "other", Line: "ignored"},
			{ID: 2, App: "web", Line: "live line"},
		})
	}()
	for sc.Scan() {
		if strings.HasPrefix(sc.Text(), "data: ") {
			if !strings.Contains(sc.Text(), "live line") {
				t.Fatalf("wrong row streamed: %s", sc.Text())
			}
			return
		}
	}
	t.Fatal("no SSE data received")
}

// Regression for the gapless live tail: the browser reconnects with
// Last-Event-ID (or since_id) after a drop. Rows the subscriber already saw
// must not be re-delivered, rows published while it was down must be.
func TestSSEResumesFromLastEventID(t *testing.T) {
	srv, _, h := setup(t)
	h.Publish([]store.LogRow{
		{ID: 10, App: "web", Line: "already seen"},
		{ID: 11, App: "web", Line: "published during the outage"},
	})
	for _, variant := range []struct{ name, url, header string }{
		{"last-event-id", "/api/logs/stream?app=web", "10"},
		{"since_id", "/api/logs/stream?app=web&since_id=10", ""},
	} {
		t.Run(variant.name, func(t *testing.T) {
			ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
			defer cancel()
			req, _ := http.NewRequestWithContext(ctx, "GET", srv.URL+variant.url, nil)
			loginIfNeeded(t)
			req.Header.Set("Authorization", "Bearer "+testToken)
			if variant.header != "" {
				req.Header.Set("Last-Event-ID", variant.header)
			}
			resp, err := http.DefaultClient.Do(req)
			if err != nil {
				t.Fatal(err)
			}
			defer resp.Body.Close()
			sc := bufio.NewScanner(resp.Body)
			sc.Scan() // ": connected"
			go func() {
				time.Sleep(100 * time.Millisecond)
				h.Publish([]store.LogRow{
					{ID: 12, App: "web", Line: "new row"},
					{ID: 13, App: "web", Line: "another"},
				})
			}()
			sawNew, sawOld := false, false
			for sc.Scan() {
				line := sc.Text()
				if strings.HasPrefix(line, "id: ") {
					if id := line[4:]; id == "10" || id == "11" {
						sawOld = true // rows before the cursor must never replay
					}
				}
				if strings.HasPrefix(line, "data: ") {
					if strings.Contains(line, "already seen") || strings.Contains(line, "outage") {
						sawOld = true
					}
					if strings.Contains(line, "new row") {
						sawNew = true
						break
					}
				}
			}
			if !sawNew {
				t.Fatal("rows after the cursor were not streamed")
			}
			if sawOld {
				t.Fatal("resume replayed rows the subscriber had already seen")
			}
		})
	}
}

// The SSE stream must be reachable by EventSource, which cannot set an
// Authorization header: /api/login mints an HttpOnly session cookie and the
// middleware must accept it as a fallback to the Bearer token.
func TestLoginSetsUsableSessionCookie(t *testing.T) {
	srv, _, _ := setup(t)
	jar := &cookieJar{}
	client := &http.Client{Jar: jar}
	req, _ := http.NewRequest("POST", srv.URL+"/api/login", strings.NewReader(`{"username":"u","password":"p"}`))
	req.Header.Set("Content-Type", "application/json")
	resp, err := client.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	resp.Body.Close()
	if len(jar.cookies) == 0 {
		t.Fatal("login did not set a session cookie")
	}
	c := jar.cookies[0]
	if c.Name != "capscope_token" || c.Value == "" || !c.HttpOnly {
		t.Fatalf("unexpected cookie %s=%q httponly=%v", c.Name, c.Value, c.HttpOnly)
	}
	// No Authorization header — the cookie alone must authenticate.
	r, err := client.Get(srv.URL + "/api/logs/stream?app=web")
	if err != nil {
		t.Fatal(err)
	}
	r.Body.Close()
	if r.StatusCode != 200 {
		t.Fatalf("SSE with cookie auth: got %d", r.StatusCode)
	}
}

// cookieJar is the minimal http.CookieJar both net/http and our assertions need.
type cookieJar struct {
	cookies []*http.Cookie
}

func (j *cookieJar) SetCookies(u *url.URL, cookies []*http.Cookie) {
	j.cookies = append(j.cookies, cookies...)
}

func (j *cookieJar) Cookies(*url.URL) []*http.Cookie { return j.cookies }

// AUTH_PROVIDER=proxy: the reverse proxy owns authentication and declares the
// caller via PROXY_USER_HEADER. No password, no sessions, and crucially the
// Bearer path must NOT authenticate anyone in this mode.
func TestProxyHeaderAuth(t *testing.T) {
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	st, err := store.Open(filepath.Join(t.TempDir(), "proxy.db"))
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { st.Close() })
	h := hub.New()
	cfg := config.Config{AuthProvider: "proxy", ProxyUserHeader: "Remote-User", SnapshotKinds: map[string]bool{}}
	dk, _ := docker.New("tcp://127.0.0.1:1")
	mgr := collector.NewManager(cfg, dk, st, h, slog.New(slog.NewTextHandler(io.Discard, nil)))
	srv := httptest.NewServer(New(cfg, st, mgr, h, slog.Default()).Handler())
	t.Cleanup(srv.Close)

	if r, err := http.Get(srv.URL + "/api/session"); err != nil || r.StatusCode != 401 {
		t.Fatalf("no identity header: want 401, got %d (err %v)", r.StatusCode, err)
	}
	// A stale or forged Bearer token must not bypass the header.
	req, _ := http.NewRequest("GET", srv.URL+"/api/session", nil)
	req.Header.Set("Authorization", "Bearer whatever")
	if r2, err := http.DefaultClient.Do(req); err != nil || r2.StatusCode != 401 {
		t.Fatalf("bearer must not bypass proxy auth: want 401, got %d (err %v)", r2.StatusCode, err)
	}

	// The proxy speaks: identity header → authenticated session state.
	preq, _ := http.NewRequest("GET", srv.URL+"/api/session", nil)
	preq.Header.Set("Remote-User", "alice")
	pr, err := http.DefaultClient.Do(preq)
	if err != nil {
		t.Fatal(err)
	}
	var sess struct {
		AuthEnabled bool   `json:"auth_enabled"`
		User        string `json:"user"`
	}
	_ = json.NewDecoder(pr.Body).Decode(&sess)
	pr.Body.Close()
	if pr.StatusCode != 200 || !sess.AuthEnabled || sess.User != "alice" {
		t.Fatalf("session = %d %+v", pr.StatusCode, sess)
	}

	// Local password login must never run in proxy mode.
	lreq, _ := http.NewRequest("POST", srv.URL+"/api/login", strings.NewReader(`{"username":"u","password":"p"}`))
	lreq.Header.Set("Content-Type", "application/json")
	if lr, err := http.DefaultClient.Do(lreq); err == nil {
		lr.Body.Close()
		if lr.StatusCode != 400 {
			t.Fatalf("login in proxy mode: want 400, got %d", lr.StatusCode)
		}
	}

	// The header wins over the port: with it set, /api/logs/stream (the
	// EventSource endpoint that cannot send headers) is reachable.
	sreq, _ := http.NewRequestWithContext(ctx, "GET", srv.URL+"/api/logs/stream?app=web", nil)
	sreq.Header.Set("Remote-User", "alice")
	sr, err := http.DefaultClient.Do(sreq)
	if err != nil {
		t.Fatal(err)
	}
	sr.Body.Close() // teardown: an open SSE body blocks Server.Close()
	if sr.StatusCode != 200 {
		t.Fatalf("SSE via proxy header: want 200, got %d", sr.StatusCode)
	}

	// A custom PROXY_USER_HEADER is honored instead of the default.
	cfg2 := cfg
	cfg2.ProxyUserHeader = "X-WebAuth-User"
	srv2 := httptest.NewServer(New(cfg2, st, mgr, h, slog.Default()).Handler())
	t.Cleanup(srv2.Close)
	if r3, err := http.Get(srv2.URL + "/api/session"); err != nil || r3.StatusCode != 401 {
		t.Fatalf("custom header unset: want 401, got %d (err %v)", r3.StatusCode, err)
	}
	wreq, _ := http.NewRequest("GET", srv2.URL+"/api/session", nil)
	wreq.Header.Set("X-WebAuth-User", "bob")
	if r4, err := http.DefaultClient.Do(wreq); err != nil || r4.StatusCode != 200 {
		t.Fatalf("custom header set: want 200, got %d (err %v)", r4.StatusCode, err)
	}
}
